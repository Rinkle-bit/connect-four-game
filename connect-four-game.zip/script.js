const ROWS = 6;
const COLS = 7;
const WIN = 4;
const TURN_SECONDS = 20;

const state = {
  board: createBoard(),
  current: "red",
  gameOver: false,
  history: [],
  scores: { red: 0, yellow: 0, draw: 0 },
  sound: true,
  timer: TURN_SECONDS,
  timerId: null,
  hintColumn: null,
  aiThinking: false
};

const els = {
  shell: document.querySelector(".app-shell"),
  board: document.getElementById("board"),
  buttons: document.getElementById("columnButtons"),
  preview: document.getElementById("columnPreview"),
  status: document.getElementById("status"),
  newGame: document.getElementById("newGame"),
  undo: document.getElementById("undoMove"),
  hint: document.getElementById("hintMove"),
  sound: document.getElementById("soundToggle"),
  mode: document.getElementById("mode"),
  difficulty: document.getElementById("difficulty"),
  theme: document.getElementById("theme"),
  timerToggle: document.getElementById("timerToggle"),
  assistToggle: document.getElementById("assistToggle"),
  redCard: document.getElementById("redCard"),
  yellowCard: document.getElementById("yellowCard"),
  redScore: document.getElementById("redScore"),
  yellowScore: document.getElementById("yellowScore"),
  drawScore: document.getElementById("drawScore"),
  redName: document.getElementById("redName"),
  yellowName: document.getElementById("yellowName"),
  moveCount: document.getElementById("moveCount"),
  turnClock: document.getElementById("turnClock"),
  history: document.getElementById("history"),
  resetScore: document.getElementById("resetScore"),
  dialog: document.getElementById("gameDialog"),
  dialogTitle: document.getElementById("dialogTitle"),
  dialogText: document.getElementById("dialogText"),
  playAgain: document.getElementById("playAgain"),
  closeDialog: document.getElementById("closeDialog"),
  fx: document.getElementById("fx")
};

function createBoard() {
  return Array.from({ length: ROWS }, () => Array(COLS).fill(null));
}

function renderBoard() {
  els.board.innerHTML = "";
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const cell = document.createElement("div");
      cell.className = "cell";
      cell.setAttribute("role", "gridcell");
      cell.dataset.row = row;
      cell.dataset.col = col;

      if (state.hintColumn === col && row === getOpenRow(col) && !state.gameOver) {
        cell.classList.add("hint");
      }

      const value = state.board[row][col];
      if (value) {
        const piece = document.createElement("span");
        piece.className = `piece ${value}`;
        piece.setAttribute("aria-label", value);
        cell.appendChild(piece);
      }
      els.board.appendChild(cell);
    }
  }
}

function renderButtons() {
  els.buttons.innerHTML = "";
  for (let col = 0; col < COLS; col++) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = col + 1;
    button.setAttribute("aria-label", `Drop in column ${col + 1}`);
    button.disabled = state.gameOver || getOpenRow(col) === -1 || state.aiThinking;
    button.addEventListener("click", () => playColumn(col));
    button.addEventListener("mouseenter", () => updatePreview(col));
    button.addEventListener("focus", () => updatePreview(col));
    button.addEventListener("mouseleave", clearPreview);
    button.addEventListener("blur", clearPreview);
    els.buttons.appendChild(button);
  }
}

function renderInfo() {
  const aiMode = els.mode.value === "ai";
  els.redName.textContent = aiMode ? "You" : "Red";
  els.yellowName.textContent = aiMode ? "AI" : "Yellow";
  els.status.textContent = statusText();
  els.redScore.textContent = state.scores.red;
  els.yellowScore.textContent = state.scores.yellow;
  els.drawScore.textContent = state.scores.draw;
  els.moveCount.textContent = state.history.length;
  els.turnClock.textContent = els.timerToggle.checked && !state.gameOver ? state.timer : "∞";
  els.redCard.classList.toggle("active", state.current === "red" && !state.gameOver);
  els.yellowCard.classList.toggle("active", state.current === "yellow" && !state.gameOver);
  els.undo.disabled = state.history.length === 0 || state.aiThinking;
  els.hint.disabled = state.gameOver || state.aiThinking;
  els.sound.setAttribute("aria-label", state.sound ? "Sound on" : "Sound off");
  els.sound.style.opacity = state.sound ? "1" : "0.48";
  renderHistory();
}

function statusText() {
  if (state.gameOver) return "Game finished";
  if (state.aiThinking) return "AI is thinking";
  const name = els.mode.value === "ai" ? (state.current === "red" ? "Your" : "AI") : title(state.current);
  return `${name} turn`;
}

function renderHistory() {
  els.history.innerHTML = "";
  [...state.history].reverse().forEach((move, index) => {
    const item = document.createElement("li");
    const number = state.history.length - index;
    item.textContent = `${number}. ${title(move.player)} dropped column ${move.col + 1}`;
    els.history.appendChild(item);
  });
}

function renderAll() {
  renderBoard();
  renderButtons();
  renderInfo();
}

function playColumn(col, fromAI = false) {
  if (state.gameOver || state.aiThinking && !fromAI) return false;
  if (els.mode.value === "ai" && state.current === "yellow" && !fromAI) return false;

  const row = getOpenRow(col);
  if (row === -1) return false;

  state.board[row][col] = state.current;
  state.history.push({ row, col, player: state.current });
  state.hintColumn = null;
  playTone(row);

  const result = getResult(state.board, row, col, state.current);
  if (result.winner) {
    state.gameOver = true;
    state.scores[state.current]++;
    highlightWin(result.cells);
    renderAll();
    showEnd(`${title(state.current)} wins`, winMessage(result.cells));
    confetti(state.current);
    stopTimer();
    return true;
  }

  if (state.history.length === ROWS * COLS) {
    state.gameOver = true;
    state.scores.draw++;
    renderAll();
    showEnd("Draw game", "Every slot is full. That board fought back.");
    stopTimer();
    return true;
  }

  state.current = other(state.current);
  state.timer = TURN_SECONDS;
  renderAll();
  restartTimer();
  maybeAI();
  return true;
}

function getOpenRow(col, board = state.board) {
  for (let row = ROWS - 1; row >= 0; row--) {
    if (!board[row][col]) return row;
  }
  return -1;
}

function getValidColumns(board = state.board) {
  return Array.from({ length: COLS }, (_, col) => col).filter((col) => getOpenRow(col, board) !== -1);
}

function getResult(board, row, col, player) {
  const directions = [
    [0, 1],
    [1, 0],
    [1, 1],
    [1, -1]
  ];

  for (const [dr, dc] of directions) {
    const cells = [[row, col]];
    cells.push(...walk(board, row, col, dr, dc, player));
    cells.push(...walk(board, row, col, -dr, -dc, player));
    if (cells.length >= WIN) return { winner: player, cells: cells.slice(0, WIN) };
  }
  return { winner: null, cells: [] };
}

function walk(board, row, col, dr, dc, player) {
  const cells = [];
  let r = row + dr;
  let c = col + dc;
  while (r >= 0 && r < ROWS && c >= 0 && c < COLS && board[r][c] === player) {
    cells.push([r, c]);
    r += dr;
    c += dc;
  }
  return cells;
}

function highlightWin(cells) {
  if (!els.assistToggle.checked) return;
  requestAnimationFrame(() => {
    cells.forEach(([row, col]) => {
      const cell = els.board.querySelector(`[data-row="${row}"][data-col="${col}"]`);
      if (cell) cell.classList.add("win");
    });
  });
}

function winMessage(cells) {
  const rows = new Set(cells.map(([row]) => row));
  const cols = new Set(cells.map(([, col]) => col));
  if (rows.size === 1) return "Four across, smooth and direct.";
  if (cols.size === 1) return "A vertical stack with no wasted motion.";
  return "A diagonal finish. Very stylish.";
}

function maybeAI() {
  if (els.mode.value !== "ai" || state.current !== "yellow" || state.gameOver) return;
  state.aiThinking = true;
  renderAll();
  window.setTimeout(() => {
    const col = chooseAIColumn();
    state.aiThinking = false;
    playColumn(col, true);
  }, 420);
}

function chooseAIColumn() {
  const level = els.difficulty.value;
  const valid = getValidColumns();
  if (level === "easy") return pickWeighted(valid);

  const win = findTacticalMove("yellow");
  if (win !== null) return win;

  const block = findTacticalMove("red");
  if (block !== null) return block;

  if (level === "medium") return pickWeighted(valid);
  return minimaxRoot(5);
}

function findTacticalMove(player) {
  for (const col of getValidColumns()) {
    const test = cloneBoard(state.board);
    const row = getOpenRow(col, test);
    test[row][col] = player;
    if (getResult(test, row, col, player).winner) return col;
  }
  return null;
}

function minimaxRoot(depth) {
  let bestScore = -Infinity;
  let bestCols = [];
  for (const col of getValidColumns()) {
    const board = cloneBoard(state.board);
    const row = getOpenRow(col, board);
    board[row][col] = "yellow";
    const score = minimax(board, depth - 1, -Infinity, Infinity, false, row, col, "yellow");
    if (score > bestScore) {
      bestScore = score;
      bestCols = [col];
    } else if (score === bestScore) {
      bestCols.push(col);
    }
  }
  return bestCols[Math.floor(Math.random() * bestCols.length)];
}

function minimax(board, depth, alpha, beta, maximizing, lastRow, lastCol, lastPlayer) {
  const result = getResult(board, lastRow, lastCol, lastPlayer);
  if (result.winner === "yellow") return 100000 + depth;
  if (result.winner === "red") return -100000 - depth;
  const valid = getValidColumns(board);
  if (depth === 0 || valid.length === 0) return scoreBoard(board);

  if (maximizing) {
    let value = -Infinity;
    for (const col of orderColumns(valid)) {
      const next = cloneBoard(board);
      const row = getOpenRow(col, next);
      next[row][col] = "yellow";
      value = Math.max(value, minimax(next, depth - 1, alpha, beta, false, row, col, "yellow"));
      alpha = Math.max(alpha, value);
      if (alpha >= beta) break;
    }
    return value;
  }

  let value = Infinity;
  for (const col of orderColumns(valid)) {
    const next = cloneBoard(board);
    const row = getOpenRow(col, next);
    next[row][col] = "red";
    value = Math.min(value, minimax(next, depth - 1, alpha, beta, true, row, col, "red"));
    beta = Math.min(beta, value);
    if (alpha >= beta) break;
  }
  return value;
}

function scoreBoard(board) {
  let score = 0;
  const center = board.map((row) => row[3]).filter(Boolean);
  score += center.filter((cell) => cell === "yellow").length * 7;
  score -= center.filter((cell) => cell === "red").length * 7;

  const lines = [];
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS - 3; c++) lines.push([board[r][c], board[r][c + 1], board[r][c + 2], board[r][c + 3]]);
  }
  for (let c = 0; c < COLS; c++) {
    for (let r = 0; r < ROWS - 3; r++) lines.push([board[r][c], board[r + 1][c], board[r + 2][c], board[r + 3][c]]);
  }
  for (let r = 0; r < ROWS - 3; r++) {
    for (let c = 0; c < COLS - 3; c++) lines.push([board[r][c], board[r + 1][c + 1], board[r + 2][c + 2], board[r + 3][c + 3]]);
  }
  for (let r = 3; r < ROWS; r++) {
    for (let c = 0; c < COLS - 3; c++) lines.push([board[r][c], board[r - 1][c + 1], board[r - 2][c + 2], board[r - 3][c + 3]]);
  }

  lines.forEach((line) => {
    score += evaluateLine(line, "yellow");
    score -= evaluateLine(line, "red");
  });
  return score;
}

function evaluateLine(line, player) {
  const mine = line.filter((cell) => cell === player).length;
  const empty = line.filter((cell) => !cell).length;
  const opponent = line.length - mine - empty;
  if (mine === 4) return 1000;
  if (mine === 3 && empty === 1) return 40;
  if (mine === 2 && empty === 2) return 8;
  if (opponent === 0 && mine === 1) return 1;
  return 0;
}

function orderColumns(cols) {
  return [...cols].sort((a, b) => Math.abs(a - 3) - Math.abs(b - 3));
}

function pickWeighted(valid) {
  const bag = [];
  valid.forEach((col) => {
    const weight = 7 - Math.abs(col - 3) * 2;
    for (let i = 0; i < weight; i++) bag.push(col);
  });
  return bag[Math.floor(Math.random() * bag.length)];
}

function cloneBoard(board) {
  return board.map((row) => [...row]);
}

function undo() {
  if (!state.history.length || state.aiThinking) return;
  const steps = els.mode.value === "ai" && state.history.length > 1 ? 2 : 1;
  for (let i = 0; i < steps; i++) {
    const move = state.history.pop();
    if (!move) break;
    state.board[move.row][move.col] = null;
    state.current = move.player;
  }
  state.gameOver = false;
  state.hintColumn = null;
  state.timer = TURN_SECONDS;
  hideEnd();
  renderAll();
  restartTimer();
}

function newGame(keepScore = true) {
  state.board = createBoard();
  state.current = "red";
  state.gameOver = false;
  state.history = [];
  state.hintColumn = null;
  state.aiThinking = false;
  state.timer = TURN_SECONDS;
  if (!keepScore) state.scores = { red: 0, yellow: 0, draw: 0 };
  hideEnd();
  renderAll();
  restartTimer();
}

function showHint() {
  const win = findTacticalMove(state.current);
  const block = findTacticalMove(other(state.current));
  state.hintColumn = win ?? block ?? pickWeighted(getValidColumns());
  renderAll();
}

function restartTimer() {
  stopTimer();
  if (!els.timerToggle.checked || state.gameOver) return;
  state.timerId = window.setInterval(() => {
    state.timer--;
    if (state.timer <= 0) {
      const valid = getValidColumns();
      playColumn(pickWeighted(valid), state.current === "yellow" && els.mode.value === "ai");
    }
    renderInfo();
  }, 1000);
}

function stopTimer() {
  if (state.timerId) window.clearInterval(state.timerId);
  state.timerId = null;
}

function updatePreview(col) {
  if (state.gameOver || getOpenRow(col) === -1) return;
  const rect = els.preview.getBoundingClientRect();
  const x = ((col + 0.5) / COLS) * rect.width;
  els.preview.style.setProperty("--preview-left", `${x}px`);
  els.preview.style.setProperty("--preview-opacity", "1");
  els.preview.style.setProperty("--preview-color", `var(--${state.current})`);
}

function clearPreview() {
  els.preview.style.setProperty("--preview-opacity", "0");
}

function showEnd(titleText, bodyText) {
  els.dialogTitle.textContent = titleText;
  els.dialogText.textContent = bodyText;
  els.dialog.classList.remove("hidden");
}

function hideEnd() {
  els.dialog.classList.add("hidden");
}

function playTone(row) {
  if (!state.sound) return;
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return;
  const ctx = new AudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.frequency.value = 220 + (ROWS - row) * 45;
  osc.type = "sine";
  gain.gain.setValueAtTime(0.001, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.07, ctx.currentTime + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.14);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + 0.16);
}

function confetti(player) {
  const ctx = els.fx.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  const rect = document.body.getBoundingClientRect();
  els.fx.width = Math.floor(window.innerWidth * dpr);
  els.fx.height = Math.floor(window.innerHeight * dpr);
  ctx.scale(dpr, dpr);

  const colors = player === "red" ? ["#f24f5e", "#ffd24a", "#ffffff", "#1c8d7f"] : ["#ffd24a", "#f24f5e", "#ffffff", "#1c8d7f"];
  const bits = Array.from({ length: 120 }, () => ({
    x: Math.random() * window.innerWidth,
    y: -20 - Math.random() * 140,
    vx: -2 + Math.random() * 4,
    vy: 2 + Math.random() * 5,
    size: 5 + Math.random() * 8,
    color: colors[Math.floor(Math.random() * colors.length)],
    spin: Math.random() * Math.PI
  }));
  let frame = 0;

  function draw() {
    ctx.clearRect(0, 0, rect.width, rect.height);
    bits.forEach((bit) => {
      bit.x += bit.vx;
      bit.y += bit.vy;
      bit.vy += 0.05;
      bit.spin += 0.16;
      ctx.save();
      ctx.translate(bit.x, bit.y);
      ctx.rotate(bit.spin);
      ctx.fillStyle = bit.color;
      ctx.fillRect(-bit.size / 2, -bit.size / 2, bit.size, bit.size * 0.55);
      ctx.restore();
    });
    frame++;
    if (frame < 150) requestAnimationFrame(draw);
    else ctx.clearRect(0, 0, rect.width, rect.height);
  }
  draw();
}

function title(text) {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function other(player) {
  return player === "red" ? "yellow" : "red";
}

els.newGame.addEventListener("click", () => newGame(true));
els.undo.addEventListener("click", undo);
els.hint.addEventListener("click", showHint);
els.sound.addEventListener("click", () => {
  state.sound = !state.sound;
  renderInfo();
});
els.mode.addEventListener("change", () => newGame(true));
els.difficulty.addEventListener("change", () => newGame(true));
els.theme.addEventListener("change", () => {
  els.shell.dataset.theme = els.theme.value;
});
els.timerToggle.addEventListener("change", () => {
  state.timer = TURN_SECONDS;
  renderInfo();
  restartTimer();
});
els.assistToggle.addEventListener("change", renderBoard);
els.resetScore.addEventListener("click", () => newGame(false));
els.playAgain.addEventListener("click", () => newGame(true));
els.closeDialog.addEventListener("click", hideEnd);

document.addEventListener("keydown", (event) => {
  const num = Number(event.key);
  if (num >= 1 && num <= 7) playColumn(num - 1);
  if (event.key.toLowerCase() === "u") undo();
  if (event.key.toLowerCase() === "h") showHint();
  if (event.key.toLowerCase() === "n") newGame(true);
});

renderAll();
restartTimer();
